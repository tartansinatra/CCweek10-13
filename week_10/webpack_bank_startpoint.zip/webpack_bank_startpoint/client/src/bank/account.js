var Account = function(params){
  this.owner = params.owner;
  this.amount = params.amount;
  this.type = params.type;
};

module.exports = Account;
