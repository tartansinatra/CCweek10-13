window.onload = function(){
  console.log('loaded');
}
