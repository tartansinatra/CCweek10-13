var checker = {
  notMinus: function(value){
    return value < 0 ? 0 : value;
  },
}

module.exports = checker;
