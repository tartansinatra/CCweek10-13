var express = require('express');
var Playlist   = require('../models/playlist');
var playlistRouter = express.Router();
var bodyParser = require('body-parser');

//set up bodyParser to use JSON
playlistRouter.use(bodyParser.urlencoded({ extended: true }));
playlistRouter.use(bodyParser.json());

//Test route to check we're up and running 
playlistRouter.get('/', function(req, res){
  res.json({ message: 'Success! My new api is here.' });   
});

//INDEX

//CREATE

//SHOW

//UPDATE

//DELETE

module.exports = playlistRouter;