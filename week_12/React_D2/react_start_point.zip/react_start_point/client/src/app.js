var React = require('react');
var ReactDOM = require('react-dom');

window.onload = function(){
  ReactDOM.render(
    <h1> React Start </h1>,
    document.getElementById('app')
  );
}
